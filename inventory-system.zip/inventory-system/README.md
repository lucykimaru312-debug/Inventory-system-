# Inventory Management System

A command-line inventory system in Python backed by a relational SQLite database. It tracks products, categories, suppliers and every stock movement, with transactional updates so stock can never go out of sync.

## Features
- Normalized schema with foreign keys, `UNIQUE` and `CHECK` constraints
- Add, search, list and delete products
- Restock and sell with atomic transactions (a failed sale changes nothing)
- Full audit trail of stock movements per product
- Low-stock report based on each product's reorder level
- Inventory summary (units, total value, low-stock count)
- CSV export
- Unit tests (`unittest`, in-memory database)

## Database design
```
categories(id, name)            suppliers(id, name)
        \                           /
         products(id, sku, name, category_id, supplier_id,
                  price, quantity, reorder_level)
                         |
                stock_movements(id, product_id, change, reason, created_at)
```
One category or supplier has many products, and one product has many stock movements (deleted together with the product via `ON DELETE CASCADE`).

## Run it
Requires Python 3.8+. No extra packages.

```bash
python main.py seed                      # load sample data
python main.py list
python main.py list --search keyboard
python main.py add USB-050 "USB Hub" 12.99 --qty 20 --category Accessories --supplier ViewCo
python main.py sell LAP-001 3
python main.py restock CBL-040 30
python main.py low
python main.py history LAP-001
python main.py summary
python main.py export products.csv
python main.py delete USB-050
```
Use `--db other.db` to work with a different database file.

## Run the tests
```bash
python -m unittest discover -s tests -t .
```

## Project structure
```
main.py              entry point
inventory/db.py      connection and schema
inventory/service.py business logic and SQL queries
inventory/cli.py     command-line interface
tests/               unit tests
```

## What I learned
- Designing a normalized relational schema and enforcing rules in the database
- Writing SQL joins, aggregates and parameterized queries (safe from SQL injection)
- Using transactions so related updates succeed or fail together
- Separating data, business logic and interface layers
- Testing with an in-memory database

## Ideas to extend
- A web interface with Flask
- Users and roles (admin vs. clerk)
- Purchase orders and customer sales
- Barcode scanning
