import unittest

from inventory import service
from inventory.db import connect


class InventoryTests(unittest.TestCase):
    def setUp(self):
        self.conn = connect(":memory:")
        service.add_product(self.conn, "A1", "Widget", 10.0, quantity=5,
                            category="Parts", supplier="Acme", reorder_level=3)

    def tearDown(self):
        self.conn.close()

    def test_duplicate_sku_rejected(self):
        with self.assertRaises(service.InventoryError):
            service.add_product(self.conn, "A1", "Other", 1.0)

    def test_negative_price_rejected(self):
        with self.assertRaises(service.InventoryError):
            service.add_product(self.conn, "B1", "Bad", -1.0)

    def test_restock_and_sell(self):
        self.assertEqual(service.restock(self.conn, "A1", 5), 10)
        self.assertEqual(service.sell(self.conn, "A1", 4), 6)

    def test_cannot_oversell(self):
        with self.assertRaises(service.InventoryError):
            service.sell(self.conn, "A1", 99)
        # failed sale must not change stock or add a movement
        self.assertEqual(service.list_products(self.conn)[0]["quantity"], 5)
        self.assertEqual(len(service.history(self.conn, "A1")), 1)

    def test_unknown_sku(self):
        with self.assertRaises(service.InventoryError):
            service.sell(self.conn, "NOPE", 1)

    def test_low_stock(self):
        self.assertEqual(service.low_stock(self.conn), [])
        service.sell(self.conn, "A1", 3)
        self.assertEqual(len(service.low_stock(self.conn)), 1)

    def test_summary_value(self):
        s = service.summary(self.conn)
        self.assertEqual(s["units"], 5)
        self.assertAlmostEqual(s["value"], 50.0)

    def test_history_records_movements(self):
        service.restock(self.conn, "A1", 2)
        service.sell(self.conn, "A1", 1)
        reasons = [r["reason"] for r in service.history(self.conn, "A1")]
        self.assertEqual(reasons, ["initial stock", "restock", "sale"])

    def test_delete_cascades_history(self):
        service.delete_product(self.conn, "A1")
        left = self.conn.execute("SELECT COUNT(*) FROM stock_movements").fetchone()[0]
        self.assertEqual(left, 0)


if __name__ == "__main__":
    unittest.main()
