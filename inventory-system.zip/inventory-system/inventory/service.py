"""Business logic: all inventory operations live here."""
import csv
import sqlite3


class InventoryError(Exception):
    """Raised for invalid operations (bad input, unknown SKU, not enough stock)."""


def _get_or_create(conn, table, name):
    """Return the id of a category/supplier, creating it if needed."""
    if not name:
        return None
    row = conn.execute(f"SELECT id FROM {table} WHERE name = ?", (name,)).fetchone()
    if row:
        return row["id"]
    return conn.execute(f"INSERT INTO {table} (name) VALUES (?)", (name,)).lastrowid


def _get_product(conn, sku):
    row = conn.execute("SELECT * FROM products WHERE sku = ?", (sku,)).fetchone()
    if row is None:
        raise InventoryError(f"No product with SKU '{sku}'")
    return row


def add_product(conn, sku, name, price, quantity=0, category=None,
                supplier=None, reorder_level=5):
    if price < 0 or quantity < 0 or reorder_level < 0:
        raise InventoryError("Price, quantity and reorder level cannot be negative")
    try:
        with conn:  # one transaction: commits on success, rolls back on error
            cat_id = _get_or_create(conn, "categories", category)
            sup_id = _get_or_create(conn, "suppliers", supplier)
            pid = conn.execute(
                "INSERT INTO products (sku, name, category_id, supplier_id, price,"
                " quantity, reorder_level) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (sku, name, cat_id, sup_id, price, quantity, reorder_level),
            ).lastrowid
            if quantity:
                conn.execute(
                    "INSERT INTO stock_movements (product_id, change, reason)"
                    " VALUES (?, ?, 'initial stock')", (pid, quantity))
    except sqlite3.IntegrityError:
        raise InventoryError(f"SKU '{sku}' already exists")


def adjust_stock(conn, sku, change, reason):
    """Change stock by `change` units and record the movement atomically."""
    with conn:
        product = _get_product(conn, sku)
        new_qty = product["quantity"] + change
        if new_qty < 0:
            raise InventoryError(
                f"Not enough stock for '{sku}': have {product['quantity']}, "
                f"need {-change}")
        conn.execute("UPDATE products SET quantity = ? WHERE id = ?",
                     (new_qty, product["id"]))
        conn.execute(
            "INSERT INTO stock_movements (product_id, change, reason) VALUES (?, ?, ?)",
            (product["id"], change, reason))
    return new_qty


def restock(conn, sku, qty):
    if qty <= 0:
        raise InventoryError("Quantity must be positive")
    return adjust_stock(conn, sku, qty, "restock")


def sell(conn, sku, qty):
    if qty <= 0:
        raise InventoryError("Quantity must be positive")
    return adjust_stock(conn, sku, -qty, "sale")


_LIST_SQL = """
SELECT p.sku, p.name, COALESCE(c.name, '-') AS category,
       COALESCE(s.name, '-') AS supplier, p.price, p.quantity, p.reorder_level
FROM products p
LEFT JOIN categories c ON c.id = p.category_id
LEFT JOIN suppliers  s ON s.id = p.supplier_id
"""


def list_products(conn, search=None):
    if search:
        like = f"%{search}%"
        return conn.execute(
            _LIST_SQL + " WHERE p.sku LIKE ? OR p.name LIKE ? OR c.name LIKE ?"
            " ORDER BY p.name", (like, like, like)).fetchall()
    return conn.execute(_LIST_SQL + " ORDER BY p.name").fetchall()


def low_stock(conn):
    return conn.execute(
        _LIST_SQL + " WHERE p.quantity <= p.reorder_level ORDER BY p.quantity"
    ).fetchall()


def history(conn, sku):
    product = _get_product(conn, sku)
    return conn.execute(
        "SELECT created_at, change, reason FROM stock_movements"
        " WHERE product_id = ? ORDER BY id", (product["id"],)).fetchall()


def delete_product(conn, sku):
    product = _get_product(conn, sku)
    with conn:
        conn.execute("DELETE FROM products WHERE id = ?", (product["id"],))


def summary(conn):
    row = conn.execute(
        "SELECT COUNT(*) AS products, COALESCE(SUM(quantity), 0) AS units,"
        " COALESCE(SUM(price * quantity), 0) AS value,"
        " COALESCE(SUM(quantity <= reorder_level), 0) AS low FROM products"
    ).fetchone()
    return dict(row)


def export_csv(conn, path):
    rows = list_products(conn)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["sku", "name", "category", "supplier", "price",
                         "quantity", "reorder_level"])
        for r in rows:
            writer.writerow(list(r))
    return len(rows)
