"""Command-line interface."""
import argparse
import sys

from . import service
from .db import connect

SAMPLE = [
    ("LAP-001", "Laptop 14in", 750.00, 12, "Computers", "TechSupply Ltd", 5),
    ("MOU-010", "Wireless Mouse", 15.50, 40, "Accessories", "TechSupply Ltd", 10),
    ("KEY-020", "Mechanical Keyboard", 49.99, 4, "Accessories", "KeyWorks", 6),
    ("MON-030", "24in Monitor", 130.00, 8, "Computers", "ViewCo", 3),
    ("CBL-040", "HDMI Cable 2m", 6.25, 2, "Cables", "KeyWorks", 10),
]


def print_table(rows, headers):
    if not rows:
        print("(no results)")
        return
    data = [[str(v) for v in r] for r in rows]
    widths = [max(len(h), *(len(r[i]) for r in data)) for i, h in enumerate(headers)]
    print("  ".join(h.ljust(w) for h, w in zip(headers, widths)))
    print("  ".join("-" * w for w in widths))
    for r in data:
        print("  ".join(v.ljust(w) for v, w in zip(r, widths)))


PRODUCT_HEADERS = ["SKU", "Name", "Category", "Supplier", "Price", "Qty", "Reorder"]


def build_parser():
    p = argparse.ArgumentParser(description="Inventory management system")
    p.add_argument("--db", default="inventory.db", help="database file")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add", help="add a product")
    a.add_argument("sku")
    a.add_argument("name")
    a.add_argument("price", type=float)
    a.add_argument("--qty", type=int, default=0)
    a.add_argument("--category")
    a.add_argument("--supplier")
    a.add_argument("--reorder", type=int, default=5)

    ls = sub.add_parser("list", help="list products")
    ls.add_argument("--search")

    for name in ("restock", "sell"):
        s = sub.add_parser(name, help=f"{name} a product")
        s.add_argument("sku")
        s.add_argument("qty", type=int)

    sub.add_parser("low", help="show products at or below reorder level")
    h = sub.add_parser("history", help="show stock movements for a product")
    h.add_argument("sku")
    d = sub.add_parser("delete", help="delete a product")
    d.add_argument("sku")
    sub.add_parser("summary", help="inventory totals")
    e = sub.add_parser("export", help="export products to CSV")
    e.add_argument("path")
    sub.add_parser("seed", help="load sample data")
    return p


def run(args, conn):
    if args.cmd == "add":
        service.add_product(conn, args.sku, args.name, args.price, args.qty,
                            args.category, args.supplier, args.reorder)
        print(f"Added {args.sku}")
    elif args.cmd == "list":
        print_table(service.list_products(conn, args.search), PRODUCT_HEADERS)
    elif args.cmd == "restock":
        print(f"{args.sku} now has {service.restock(conn, args.sku, args.qty)} units")
    elif args.cmd == "sell":
        print(f"{args.sku} now has {service.sell(conn, args.sku, args.qty)} units")
    elif args.cmd == "low":
        print_table(service.low_stock(conn), PRODUCT_HEADERS)
    elif args.cmd == "history":
        print_table(service.history(conn, args.sku), ["When", "Change", "Reason"])
    elif args.cmd == "delete":
        service.delete_product(conn, args.sku)
        print(f"Deleted {args.sku}")
    elif args.cmd == "summary":
        s = service.summary(conn)
        print(f"Products:        {s['products']}")
        print(f"Total units:     {s['units']}")
        print(f"Inventory value: {s['value']:.2f}")
        print(f"Low-stock items: {s['low']}")
    elif args.cmd == "export":
        print(f"Exported {service.export_csv(conn, args.path)} products to {args.path}")
    elif args.cmd == "seed":
        for sku, name, price, qty, cat, sup, reorder in SAMPLE:
            try:
                service.add_product(conn, sku, name, price, qty, cat, sup, reorder)
            except service.InventoryError:
                pass
        print("Sample data loaded")


def main(argv=None):
    args = build_parser().parse_args(argv)
    conn = connect(args.db)
    try:
        run(args, conn)
    except service.InventoryError as e:
        sys.exit(f"Error: {e}")
    finally:
        conn.close()
